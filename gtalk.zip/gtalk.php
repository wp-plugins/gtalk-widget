<?php
/*
Plugin Name: Gtalk
Description: Adds Gtalk widget in your side bar
Author: Kinshuk Kulshreshtha
Version: 1.0
Author URI: http://www.anshisolutions.com

*/
function widget_gtalk_init() {
 
if ( !function_exists('register_sidebar_widget') )
		return;
		
function widget_gtalk($args) {
		extract($args);
$defaults = array('title' => '', 'width' => '250', 'height' => '500');
		$options = (array) get_option('widget_gtalk');
		
		foreach ( $defaults as $key => $value )
			if ( !isset($options[$key]) )
				$options[$key] = $defaults[$key];
				
		echo $before_widget;

		
?>		
<script src="http://gmodules.com/ig/ifr?url=http://www.google.com/ig/modules/googletalk.xml&amp;synd=open&amp;w=<?php  echo $options['width']; ?>&amp;h=<?php  echo $options['height']; ?>&amp;title=<?php  echo $options['title']; ?>&amp;lang=en&amp;country=US&amp;border=%23ffffff%7C3px%2C1px+solid+%23999999&amp;output=js"></script>

<?php		
  echo $after_widget;
		
}

function widget_gtalk_control() {
	$options = get_option('widget_gtalk');
		if ( !is_array($options) )
			$options = array('title' => '', 'width' => '', 'height' => '');
		if ( $_POST['gtalk-submit'] ) {

			$options['title'] = strip_tags(stripslashes($_POST['gtalk-title']));
			$options['width'] = strip_tags(stripslashes($_POST['gtalk-width']));
			$options['height'] = strip_tags(stripslashes($_POST['gtalk-height']));
			update_option('widget_gtalk', $options);
		}
		
	        $title = htmlspecialchars($options['title'], ENT_QUOTES);
		$width = htmlspecialchars($options['width'], ENT_QUOTES);
		$height = htmlspecialchars($options['height'], ENT_QUOTES);
		
		echo '<p style="text-align:right;"><label for="gtalk-title">Title: <input style="width: 200px;" id="gtalk-title" name="gtalk-title" type="text" value="'.$title.'" /></label></p>
		<p style="text-align:right;"><label for="gtalk-width">Width: <input style="width: 200px;" id="gtalk-width" name="gtalk-width" type="text" value="'.$width.'" /></label></p>
		<p style="text-align:right;"><label for="gtalk-height">Height: <input style="width: 200px;" id="gtalk-height" name="gtalk-height" type="text" value="'.$height.'" /></label></p>
		<input type="hidden" id="gtalk-submit" name="gtalk-submit" value="1" />';
	}

        $widget_ops = array('classname' => 'widget_gtalk', 'description' => __( "Gtalk widget for your sidebar") );
	wp_register_sidebar_widget('Gtalk', __('Gtalk'), 'widget_gtalk', $widget_ops);

	register_widget_control('Gtalk', 'widget_gtalk_control', 300, 265);
}
	add_action('plugins_loaded', 'widget_gtalk_init');
?>